package com.example.administrator.yihubaiyin;

import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;


public  class yonghuxinxi {
    HashMap hs=new HashMap();
    boolean bl=true;

  boolean  yonghuxinxi(String zhucename, String zhucepassword, String zhucexinbie){


        adduser add=new adduser();
        Set keyset=hs.keySet();
        Iterator it=keyset.iterator();

  while(it.hasNext()){
      String key=(String) it.next();
      if (key==zhucename){
          bl=false;

      }

  }
  if (bl==true){
    hs.put(zhucename,add.adduser(zhucepassword,zhucexinbie));}

   return bl;
}

boolean denglujiance(String jiancename ,String jiancepassword){
     boolean bl2=false;



      if (hs.containsKey(jiancename)==true){
          Iterator it=((ArrayList)hs.get(jiancename)).iterator();
          String s=(String) it.next();
          if (s==jiancepassword){
            bl2=true;

          }
      }

return bl2;

}

}
class adduser{


    ArrayList  adduser(String password,String xinbie){
        ArrayList arrayList=new ArrayList();

        arrayList.add(password);
        arrayList.add(xinbie);
        return arrayList;

    }
}